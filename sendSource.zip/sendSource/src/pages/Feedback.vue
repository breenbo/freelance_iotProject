<template>
  <div>
    Feedback : add just a modal with a form ?
  </div>
</template>

<script lang="ts">
import Vue from 'vue';
export default Vue.extend({});
</script>

<style lang="scss" scoped>
</style>