<template>
  <div>
    When a user wants to create a new product a dialog or q-page should be displayed that
    prompts for the following information:
    ● Name of the product
    The newly created product becomes the active product in the dashboard and it’s name should
    be displayed in the header area. Upon creation the app should transition to the Firmware
    Overview screen so a firmware binary can be uploaded.
  </div>
</template>

<script lang="ts">
import Vue from 'vue';
export default Vue.extend({});
</script>

<style lang="scss" scoped>
</style>
