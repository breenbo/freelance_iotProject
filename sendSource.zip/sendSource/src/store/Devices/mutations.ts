import { MutationTree } from 'vuex';
import { DevicesStateInterface } from './state';

const mutation: MutationTree<DevicesStateInterface> = {
  someMutation(/* state: ExampleStateInterface */) {
    // your code
  }
};

export default mutation;
