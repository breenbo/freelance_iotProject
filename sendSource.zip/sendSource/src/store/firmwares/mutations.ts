import { MutationTree } from 'vuex';
import { FirmwareStateInterface } from './state';

const mutation: MutationTree<FirmwareStateInterface> = {
  someMutation(/* state: ExampleStateInterface */) {
    // your code
  }
};

export default mutation;
